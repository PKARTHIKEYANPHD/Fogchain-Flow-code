package sample;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CloudNode 
{
    private Map<String, ArrayList<String>> cloudNodeDataStorage;
    private int storageCapacity;
    private int usedStorage;

    public CloudNode(int storageCapacity) 
    {
        cloudNodeDataStorage = new HashMap<>();
        this.storageCapacity = storageCapacity;
        this.usedStorage = 0;
    }

    public void receiveDataFromFogDevice(String data, long encryptionTime) 
    {
    	System.out.println("Time taken for encryption: " + encryptionTime + " milliseconds");
    	storeData(data);
    }

    private void storeData(String data) 
    {
    	if (usedStorage < storageCapacity) 
    	{
    	// Store data received from FogDevice
    		if (!cloudNodeDataStorage.containsKey(data)) 
    		{
    			cloudNodeDataStorage.put(data, new ArrayList<>());
    		}
    		cloudNodeDataStorage.get(data).add(data);
    		usedStorage++; // Increment used storage
    		//System.out.println("Data stored in CloudNode. Remaining storage: " + (storageCapacity - usedStorage));
    	} 
    	else 
    	{
    		System.out.println("CloudNode storage is full.");
    	}
    }

    public void displayStoredData() 
    {
        System.out.println("\nFog Device Data stored in CloudNode:");
        for (String key : cloudNodeDataStorage.keySet()) 
        {
        	ArrayList<String> dataList = cloudNodeDataStorage.get(key);
        	for (String data : dataList) 
        	{
                System.out.println("\n" + data + "\n");
            }
        }
        System.out.println("\n");
        System.out.println("Remaining storage of Cloud is: " + (storageCapacity - usedStorage));
    }
 }
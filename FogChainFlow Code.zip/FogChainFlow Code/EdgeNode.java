package sample;
import java.util.*;
public class EdgeNode 
{
	private ArrayList<Sensor> sensors;
	private String nodeName;
	private Map<EdgeNode, ArrayList<String>> edgeNodeDataStorage;
	private ArrayList<FogNode> fogNodes;
    private ArrayList<FogDevice> fogDevices;
    private int fogNodeIndex;
    private int fogDeviceIndex;

    public EdgeNode(String nodeName) 
    {
    	this.nodeName = nodeName;
    	this.sensors = new ArrayList<>();
    	this.edgeNodeDataStorage = new HashMap<>();
    	this.fogNodes = new ArrayList<>();
        this.fogDevices = new ArrayList<>();
        this.fogNodeIndex = 0;
        this.fogDeviceIndex = 0;
    }

    // Method to add a Sensor to the EdgeNode
    public void addSensor(Sensor sensor) 
    {
        sensors.add(sensor);
    }
    
    public String getNodeName() 
    {
        return nodeName;
    }
    
    public void addFogNode(FogNode fogNode) 
    {
        if (fogNodes == null) 
        {
            fogNodes = new ArrayList<>();
        }
        fogNodes.add(fogNode);
    }
    
    public void addFogDevice(FogDevice fogDevice) 
    {
        if (fogDevices == null) {
            fogDevices = new ArrayList<>();
        }
        fogDevices.add(fogDevice);
    }
    
    // Method to receive blood pressure data from the Sensor
    public void receiveBloodPressureData(Sensor sensor,int systolicPressure, int diastolicPressure, int heartRate, double bodytemperature) 
    {
    	String data = "Received Blood Pressure Data, HeartRate and Body Temperature Data : Systolic: " + systolicPressure + " Diastolic: " + diastolicPressure + " HeartRate: " + heartRate + " BodyTemperature: " + bodytemperature;
        System.out.println(nodeName + data);
        analyzeData(sensor, systolicPressure, diastolicPressure,heartRate, bodytemperature, data);
        storeData(this,data); // Store data edge-wise
    }
    
    private void analyzeData(Sensor sensor,int systolicPressure, int diastolicPressure, int heartRate,double bodyTemperature, String data)
    {
    	boolean isBloodPressureNormal = (systolicPressure >= 90 && systolicPressure <= 120) && (diastolicPressure >= 60 && diastolicPressure <= 80);
        boolean isHeartRateNormal = (heartRate >= 60 && heartRate <= 100);
        boolean isBodyTemperatureNormal = (bodyTemperature >= 97 && bodyTemperature <= 99);
        
        /*if (isBloodPressureNormal && isHeartRateNormal && isBodyTemperatureNormal) 
        {
            System.out.println("All parameters are normal.");
            forwardDataToFogDevice(systolicPressure, diastolicPressure, heartRate, bodyTemperature);
        } 
        else 
        {
            System.out.println("Abnormal parameters detected:");
            if (!isBloodPressureNormal) 
            {
                System.out.println("- Blood pressure is abnormal.");
                forwardDataToFogNode(systolicPressure, diastolicPressure);
            }
            if (!isHeartRateNormal) 
            {
                System.out.println("- Heart rate is abnormal.");
                forwardHeartRateToFogNode(heartRate);
            }
            if (!isBodyTemperatureNormal) 
            {
                System.out.println("- Body temperature is abnormal.");
                forwardBodyTemperatureToFogNode(bodyTemperature);
            }
        }*/

        if (!isBloodPressureNormal)
        {
            System.out.println("\nAbnormal Blood Pressure");
            forwardDataToFogNode(systolicPressure, diastolicPressure);
            if (!isHeartRateNormal)
            {
                System.out.println("\nAbnormal HeartRate");
                forwardHeartRateToFogNode(heartRate);
                if(!isBodyTemperatureNormal)
                {
                	System.out.println("\nAbnormal BodyTemperature");
                	forwardBodyTemperatureToFogNode(bodyTemperature);
                }
                else
                {
                	System.out.println("\nNormal BodyTemperature");
                	forwardDataToFogDevice(bodyTemperature);
                }
            }
            else if(isHeartRateNormal)
            {
            	System.out.println("\nNormal HeartRate");
            	forwardDataToFogDevice(heartRate);
            	if(!isBodyTemperatureNormal)
                {
                	System.out.println("\nAbnormal BodyTemperature");
                	forwardBodyTemperatureToFogNode(bodyTemperature);
                }
            	else
                {
                	System.out.println("\nNormal BodyTemperature");
                	forwardDataToFogDevice(bodyTemperature);
                }
            }
        }
        else if(isBloodPressureNormal)
        {
        	System.out.println("\nNormal Blood Pressure");
        	forwardDataToFogDevice(systolicPressure, diastolicPressure);
        	if(!isHeartRateNormal)
        	{
        		System.out.println("\nAbnormal HeartRate");
        		forwardHeartRateToFogNode(heartRate);
        		if(!isBodyTemperatureNormal)
                {
                	System.out.println("\nAbnormal BodyTemperature");
                	forwardBodyTemperatureToFogNode(bodyTemperature);
                }
            	else
                {
                	System.out.println("\nNormal BodyTemperature");
                	forwardDataToFogDevice(bodyTemperature);
                }
        	}
        	else
            {
        		System.out.println("\nNormal HeartRate");
            	forwardDataToFogDevice(heartRate);
            	if(!isBodyTemperatureNormal)
                {
                	System.out.println("\nAbnormal BodyTemperature");
                	forwardBodyTemperatureToFogNode(bodyTemperature);
                }
            	else
                {
                	System.out.println("\nNormal BodyTemperature");
                	forwardDataToFogDevice(bodyTemperature);
                }
            }
        }
        else
        {
            System.out.println("\nNormal Blood Pressure, HeartRate, and BodyTemperature");
            forwardDataToFogDevice(systolicPressure, diastolicPressure, heartRate, bodyTemperature); 
        }
        
    }
    
    private void forwardDataToFogDevice(int systolicPressure, int diastolicPressure, int heartRate, double bodyTemperature) 
    {
        if (fogDevices.isEmpty()) 
        {
            System.out.println("No Fog Devices available.");
            return;
        }
        FogDevice fogDevice = fogDevices.get(fogDeviceIndex);
        System.out.println("\nFogDevice: " + fogDeviceIndex);
        fogDevice.receiveDataFromEdgeNode(fogDeviceIndex, this.nodeName, systolicPressure, diastolicPressure, heartRate, bodyTemperature);
        fogDeviceIndex = (fogDeviceIndex + 1) % fogDevices.size(); // Round-robin assignment
    }
    
    private void forwardDataToFogDevice(int systolicPressure, int diastolicPressure) 
    {
        if (fogDevices.isEmpty()) 
        {
            System.out.println("No Fog Devices available.");
            return;
        }
        FogDevice fogDevice = fogDevices.get(fogDeviceIndex);
        System.out.println("\nFogDevice: " + fogDeviceIndex);
        fogDevice.receiveDataFromEdgeNode(fogDeviceIndex, this.nodeName, systolicPressure, diastolicPressure);
        fogDeviceIndex = (fogDeviceIndex + 1) % fogDevices.size(); // Round-robin assignment
    }
    private void forwardDataToFogDevice(int heartRate) 
    {
        if (fogDevices.isEmpty()) 
        {
            System.out.println("No Fog Devices available.");
            return;
        }
        FogDevice fogDevice = fogDevices.get(fogDeviceIndex);
        System.out.println("\nFogDevice: " + fogDeviceIndex);
        fogDevice.receiveDataFromEdgeNode(fogDeviceIndex, this.nodeName, heartRate);
        fogDeviceIndex = (fogDeviceIndex + 1) % fogDevices.size(); // Round-robin assignment
    }
    private void forwardDataToFogDevice(double bodyTemperature) 
    {
        if (fogDevices.isEmpty()) 
        {
            System.out.println("No Fog Devices available.");
            return;
        }
        FogDevice fogDevice = fogDevices.get(fogDeviceIndex);
        System.out.println("\nFogDevice: " + fogDeviceIndex);
        fogDevice.receiveDataFromEdgeNode(fogDeviceIndex, this.nodeName, bodyTemperature);
        fogDeviceIndex = (fogDeviceIndex + 1) % fogDevices.size(); // Round-robin assignment
    }
    
    private void forwardDataToFogNode(int systolicPressure, int diastolicPressure) 
    {
        if (fogNodes.isEmpty()) 
        {
            System.out.println("No Fog Nodes available.");
            return;
        }
        
        FogNode fogNode = fogNodes.get(fogNodeIndex);
        System.out.println("\nFogNode: " + fogNodeIndex);
        fogNode.receiveDataFromEdgeNode(fogNodeIndex, this.nodeName, systolicPressure, diastolicPressure);
        fogNodeIndex = (fogNodeIndex + 1) % fogNodes.size(); // Round-robin assignment
    }

    private void forwardHeartRateToFogNode(int heartRate) 
    {
        if (fogNodes.isEmpty()) 
        {
            System.out.println("No Fog Nodes available.");
            return;
        }
        
        FogNode fogNode = fogNodes.get(fogNodeIndex);
        System.out.println("\nFogNode: " + fogNodeIndex);
        fogNode.receiveHeartRateData(fogNodeIndex,this.nodeName, heartRate);
        fogNodeIndex = (fogNodeIndex + 1) % fogNodes.size(); // Round-robin assignment
    }
    
    private void forwardBodyTemperatureToFogNode(double bodyTemperature) 
    {
        if (fogNodes.isEmpty()) 
        {
            System.out.println("No Fog Nodes available.");
            return;
        }
        
        FogNode fogNode = fogNodes.get(fogNodeIndex);
        System.out.println("\nFogNode: " + fogNodeIndex);
        fogNode.receiveBodyTemperatureData(fogNodeIndex,this.nodeName, bodyTemperature);
        fogNodeIndex = (fogNodeIndex + 1) % fogNodes.size(); // Round-robin assignment
    }
    private void storeData(EdgeNode edgeNode, String data) 
    {
        if (!edgeNodeDataStorage.containsKey(edgeNode)) {
            edgeNodeDataStorage.put(edgeNode, new ArrayList<>());
        }
        edgeNodeDataStorage.get(edgeNode).add(data);
    }
    
    // Method to retrieve stored data for a specific EdgeNode
    public ArrayList<String> getDataForEdgeNode(EdgeNode edgeNode) 
    {
        return edgeNodeDataStorage.getOrDefault(edgeNode, new ArrayList<>());
    }
    
    // Method to print stored data for a specific EdgeNode
    public void printDataForEdgeNode(EdgeNode edgeNode) 
    {
        ArrayList<String> storedData = getDataForEdgeNode(edgeNode);

        if (storedData.isEmpty()) 
        {
            System.out.println("No data found for " + edgeNode.getNodeName());
        } 
        else 
        {
            for (String data : storedData) 
            {
                System.out.println(data);
            }
        }
    }
}

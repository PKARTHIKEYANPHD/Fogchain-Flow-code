package sample;

import java.util.ArrayList;
import java.util.Map;
import java.util.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.TimeUnit;

public class FogNode 
{
	private Map<String, ArrayList<String>> fogNodeDataStorage;
	private List<FogNode> allOtherFogNodes;
	private int fogNodeIndex;
	private static final int DIFFICULTY = 5; // Difficulty for PoW
    private List<Block1> blockchain;
    private List<String> receivedData;
    private int storageCapacity;
    private int usedStorage;

   	
	public FogNode(List<FogNode> allOtherFogNodes, int storageCapacity) 
	{
		this.receivedData = new ArrayList<>();
        allOtherFogNodes.add(this);
		this.allOtherFogNodes = allOtherFogNodes != null ? new ArrayList<>(allOtherFogNodes) : new ArrayList<>();
		fogNodeDataStorage = new HashMap<>(); // Initialize fogNodeDataStorage in the constructor
        fogNodeIndex = 0;
        this.storageCapacity = storageCapacity;
        this.usedStorage = 0;
		blockchain = new ArrayList<>();
        // Create the genesis block when initializing FogNode
        Block1 genesisBlock = new Block1(0, "Genesis Block", "0");
        genesisBlock.mineBlock(DIFFICULTY);
        blockchain.add(genesisBlock);
   }
	
	public void receiveData(String data) 
	{
        receivedData.add(data);
    }

    public String getNodeName() 
	{
        // Implement logic to return the FogNode name or identifier
        return "FogNode"; // Replace this with actual node name logic
    }
	
	public void receiveDataFromEdgeNode(int fogindex, String edgeNodeName,int systolicPressure, int diastolicPressure) 
	{
		String data = "Received Blood Pressure Data: Systolic: " + systolicPressure + ", Diastolic: " + diastolicPressure; 
		System.out.println(data + "\n");
        storeData(data);
        fogNodeIndex = fogindex;
        simulateNetworkDelay();
        // Perform processing specific to Fog Node with the received data
        //addToBlockchain(systolicPressure,diastolicPressure);
        addToBlockchain(data);
    }
	
	public void receiveHeartRateData(int fogindex, String edgeNodeName, int heartRate) 
	{
		String data = "Received HeartRate Data: " + heartRate; 
		System.out.println(data + "\n");
        storeData(data);
        fogNodeIndex = fogindex;
        simulateNetworkDelay();
        // Perform processing specific to Fog Node with the received data
        //addToBlockchain(heartRate);
        addToBlockchain(data);
    }
	
	public void receiveBodyTemperatureData(int fogindex, String edgeNodeName, double bodyTemperature) 
	{
		String data = "Received BodyTemperature Data: " + bodyTemperature; 
		System.out.println(data + "\n");
        storeData(data);
        fogNodeIndex = fogindex;
        simulateNetworkDelay();
        // Perform processing specific to Fog Node with the received data
        //addToBlockchain(heartRate);
        addToBlockchain(data);
    }
	private void simulateNetworkDelay() 
	{
        try {
            // Simulate network delay of 1 to 5 seconds
            long delay = (long) (Math.random() * 4000) + 1000;
            TimeUnit.MILLISECONDS.sleep(delay);
            System.out.println("Simulated network delay: " + delay + " milliseconds");
        } 
        catch (InterruptedException e) 
        {
            e.printStackTrace();
        }
    }
    private void storeData(String data) 
    {
    	if (usedStorage < storageCapacity) 
    	{
    		// Store data received in Fog Node
    		if (!fogNodeDataStorage.containsKey(data)) 
    		{
    			fogNodeDataStorage.put(data, new ArrayList<>());
    		}
    		fogNodeDataStorage.get(data).add(data);
    		usedStorage++; // Increment used storage
            //System.out.println("Data stored in FogNode. Remaining storage: " + (storageCapacity - usedStorage));
        } 
    	else 
    	{
            System.out.println("FogNode storage is full.");
        }
    }

      
    /*private void addToBlockchain(int systolicPressure, int diastolicPressure) 
    {
        Block1 previousBlock = blockchain.get(blockchain.size() - 1);
        int newIndex = previousBlock.getIndex() + 1; // Increment block index
        
       if (allOtherFogNodes != null) {
            int maxIndex = newIndex;
            for (FogNode otherFogNode : allOtherFogNodes) {
                maxIndex = Math.max(maxIndex, otherFogNode.getBlockchain().size());
            }
            newIndex = maxIndex;
        }
        if (this.fogNodeIndex >= 0 || this.fogNodeIndex <= 10) 
        {
        	Block1 newBlock = new Block1(newIndex, systolicPressure, diastolicPressure, previousBlock.getHash());
        	newBlock.mineBlock(DIFFICULTY);
        	blockchain.add(newBlock);
        }
        if (allOtherFogNodes != null) 
        {
            for (FogNode otherFogNode : allOtherFogNodes) 
            {
                if (!otherFogNode.equals(this) && allOtherFogNodes.contains(otherFogNode)) 
                {
                    otherFogNode.receiveUpdatedBlockchain(new ArrayList<>(blockchain)); // Send a copy of the blockchain
                }
            }
        } 
        else 
        {
            System.out.println("List of all other FogNodes is not initialized.");
        }
    }
    
    private void addToBlockchain(int heartRate) 
    {
        Block1 previousBlock = blockchain.get(blockchain.size() - 1);
        int newIndex = previousBlock.getIndex() + 1; // Increment block index
        
       if (allOtherFogNodes != null) {
            int maxIndex = newIndex;
            for (FogNode otherFogNode : allOtherFogNodes) {
                maxIndex = Math.max(maxIndex, otherFogNode.getBlockchain().size());
            }
            newIndex = maxIndex;
        }
        if (this.fogNodeIndex >= 0 || this.fogNodeIndex <= 10) 
        {
        	Block1 newBlock = new Block1(newIndex, heartRate, previousBlock.getHash());
        	newBlock.mineBlock(DIFFICULTY);
        	blockchain.add(newBlock);
        }
        if (allOtherFogNodes != null) 
        {
            for (FogNode otherFogNode : allOtherFogNodes) 
            {
                if (!otherFogNode.equals(this) && allOtherFogNodes.contains(otherFogNode)) 
                {
                    otherFogNode.receiveUpdatedBlockchain(new ArrayList<>(blockchain)); // Send a copy of the blockchain
                }
            }
        } 
        else 
        {
            System.out.println("List of all other FogNodes is not initialized.");
        }
    }*/
    
    private void addToBlockchain(String data) 
    {
        Block1 previousBlock = blockchain.get(blockchain.size() - 1);
        int newIndex = previousBlock.getIndex() + 1; // Increment block index

        if (allOtherFogNodes != null) 
        {
            int maxIndex = newIndex;
            for (FogNode otherFogNode : allOtherFogNodes) 
            {
                maxIndex = Math.max(maxIndex, otherFogNode.getBlockchain().size());
            }
            newIndex = maxIndex;
        }

        if (this.fogNodeIndex >= 0 || this.fogNodeIndex <= 10) 
        {
            Block1 newBlock = new Block1(newIndex, data, previousBlock.getHash());
            newBlock.mineBlock(DIFFICULTY);
            blockchain.add(newBlock);
        }

        if (allOtherFogNodes != null) 
        {
            for (FogNode otherFogNode : allOtherFogNodes) 
            {
                if (!otherFogNode.equals(this) && allOtherFogNodes.contains(otherFogNode)) 
                {
                    otherFogNode.receiveUpdatedBlockchain(new ArrayList<>(blockchain)); // Send a copy of the blockchain
                }
            }
        } 
        else 
        {
            System.out.println("List of all other FogNodes is not initialized.");
        }
    }
    public void receiveUpdatedBlockchain(List<Block1> newBlockchain) 
    {
        if (isValidChain(newBlockchain)) {
        	for (FogNode fogNode : allOtherFogNodes) {
                fogNode.updateBlockchain(newBlockchain);
            }
        }
    }
  
    public void updateBlockchain(List<Block1> newBlockchain) 
    {
        if (isValidChain(newBlockchain)) 
        {
            for (Block1 block : newBlockchain) 
            {
                if (!(block.getIndex() == 0 && block.getData().equals("Genesis Block"))) {
                    boolean blockExists = false;
                    for (Block1 existingBlock : blockchain) 
                    {
                        if (block.getHash().equals(existingBlock.getHash())) 
                        {
                            blockExists = true;
                            break;
                        }
                    }
                    if (!blockExists) {
                        blockchain.add(block);
                    }
                }
            }
        }
    }
         
    public void printDataForFogNode() 
    {
    	//System.out.println("Fog-Integrated Blockchain Ledger" + "\n\n");
        if(fogNodeIndex == 0)
        {
        	System.out.println("Fog-Integrated Blockchain Ledger" + "\n\n");
        	for (Block1 block : blockchain) 
        	{
        		//System.out.println("Block " + block.getIndex() + ": " + block.getData());
        		System.out.println(block.toString());
        		System.out.println("\n");
        	}
        }
        System.out.println("Remaining storage FogNode: " + fogNodeIndex + " is " + (storageCapacity - usedStorage));
    }
    
       
    public List<Block1> getBlockchain() {
        return blockchain;
    }
       
    private boolean isValidChain(List<Block1> chain) 
    {
        for (int i = 1; i < chain.size(); i++) 
        {
            Block1 currentBlock = chain.get(i);
            Block1 previousBlock = chain.get(i - 1);

            if (!currentBlock.getPreviousHash().equals(previousBlock.getHash())) 
            {
                return false;
            }
        }
        return true;
    }
    
}

class Block1 
{
    private int index;
    private String data;
    private String previousHash;
    private String hash;
    private long timeStamp;
    private double transactionFee;
    private double gasPrice;
    private int nonce;
    public int systolicPressure;
    public int diastolicPressure;
    public int heartRate;
    public double bodyTemperature;
      
    public Block1(int index, String data, String previousHash) 
    {
        this.index = index;
        this.data = data;
        this.previousHash = previousHash;
        this.timeStamp = new Date().getTime();
        this.nonce = 0;
        this.hash = calculateHash();
        calculateTransactionDetails(); 
    }
    public Block1(int index, int systolicPressure, int diastolicPressure,String previousHash) 
    {
        this.index = index;
        this.systolicPressure = systolicPressure;
        this.diastolicPressure = diastolicPressure;
        this.previousHash = previousHash;
        this.timeStamp = new Date().getTime();
        this.nonce = 0;
        this.data = "Received Blood Pressure Data: Systolic: " + systolicPressure + ", Diastolic: " + diastolicPressure;
        this.hash = calculateHash();
        calculateTransactionDetails(); 
    }
    
    public Block1(int index, int heartRate,String previousHash) 
    {
        this.heartRate = heartRate;
        this.previousHash = previousHash;
        this.timeStamp = new Date().getTime();
        this.nonce = 0;
        this.data = "Received HeartRate Data: " + heartRate;
        this.hash = calculateHash();
        calculateTransactionDetails(); 
    }
    
    public Block1(int index, double bodyTemperature,String previousHash) 
    {
        this.bodyTemperature = bodyTemperature;
        this.previousHash = previousHash;
        this.timeStamp = new Date().getTime();
        this.nonce = 0;
        this.data = "Received BodyTemperature Data: " + bodyTemperature;
        this.hash = calculateHash();
        calculateTransactionDetails(); 
    }

    public int getIndex() 
    {
        return index;
    }

    public String getData() 
    {
        return data;
    }

    public String getPreviousHash() 
    {
        return previousHash;
    }
    public String getHash() {
        return hash;
    }
    private String calculateHash() 
    {
    	String dataToHash = index + previousHash + timeStamp + nonce + data;
        StringBuilder hash = new StringBuilder();

        try 
        {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedHash = digest.digest(dataToHash.getBytes());

            for (byte b : encodedHash) {
                hash.append(String.format("%02x", b));
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return hash.toString();
    }
    public void mineBlock(int difficulty) 
    {
        String target = new String(new char[difficulty]).replace('\0', '0'); // Create a string with difficulty * "0"

        while (!hash.substring(0, difficulty).equals(target)) 
        {
            nonce++;
            hash = calculateHash();
        }
        //calculateTransactionDetails();
    }
    
    private void calculateTransactionDetails() 
    {
        transactionFee = calculateTransactionFee();
        gasPrice = calculateGasPrice();
        System.out.println("Transaction Fees: " + transactionFee + "   " +"GasPrice: " + gasPrice + "\n");
    }
    /*private double calculateTransactionFee() 
    {
        // Example logic: calculate transaction fee based on the length of the data
        double baseFee = 0.5; // a base fee for any transaction
        double feePerCharacter = 0.1; // additional fee per character in the data

        int dataLength = data.length(); // assuming 'data' is the content of the block

        // Calculate transaction fee based on the length of the data
        double calculatedTransactionFee = baseFee + (feePerCharacter * dataLength);

        return calculatedTransactionFee;
    }*/
    private double calculateTransactionFee() 
    {
        
        double baseFee = 0.5; // a base fee for any transaction
        double complexityFactor = 0.05; // a factor to adjust fee based on data complexity
        double dataComplexity = calculateDataComplexity(systolicPressure, diastolicPressure);
        double calculatedTransactionFee = baseFee + (complexityFactor * dataComplexity);
        return calculatedTransactionFee;
    }
    private double calculateDataComplexity(int systolicPressure, int diastolicPressure) 
    {
        double rangeComplexity = calculateRangeComplexity(systolicPressure, diastolicPressure);
        double interdependencyComplexity = calculateInterdependencyComplexity(systolicPressure, diastolicPressure);
        double complexity = 0.6 * rangeComplexity + 0.4 * interdependencyComplexity;
        return Math.max(0.0, Math.min(1.0, complexity));
    }

    private double calculateRangeComplexity(int systolicPressure, int diastolicPressure) 
    {
        
        double systolicRange = 120.0;  // Example: Normal range for systolic pressure
        double diastolicRange = 80.0;  // Example: Normal range for diastolic pressure
        // Calculate the percentage of deviation from the normal range
        double systolicDeviation = Math.abs(systolicPressure - systolicRange) / systolicRange;
        double diastolicDeviation = Math.abs(diastolicPressure - diastolicRange) / diastolicRange;
        // Calculate the average deviation
        double averageDeviation = (systolicDeviation + diastolicDeviation) / 2.0;
        // Normalize the deviation to the range [0, 1]
        return 1.0 - Math.min(1.0, averageDeviation);
    }

    private double calculateInterdependencyComplexity(int systolicPressure, int diastolicPressure) 
    {
        
        double interdependencyFactor = 0.8;  // Example: High interdependency between systolic and diastolic pressures
        return Math.max(0.0, Math.min(1.0, interdependencyFactor));
    }
    /*private double calculateGasPrice() 
    {
        double baseGasPrice = 0.1; // a base gas price for any transaction
        double demandFactor = 1.2; // a factor to adjust gas price based on network demand
        double complexityFactor = 1.5; // a factor to adjust gas price based on transaction complexity
        double calculatedGasPrice = baseGasPrice * demandFactor * complexityFactor;
        return calculatedGasPrice;
    }*/
    
    private double calculateGasPrice() 
    {
        double baseGasPrice = 0.1; // a base gas price for any transaction
        double demandFactor = calculateDynamicDemandFactor();
        double complexityFactor = 1.5; // a factor to adjust gas price based on transaction complexity
        double calculatedGasPrice = baseGasPrice * demandFactor * complexityFactor;
        return calculatedGasPrice;
    }

    private double calculateDynamicDemandFactor() 
    {
        // Simulating a dynamic demand factor within the specified range
        Random random = new Random();
        double minDemandFactor = 1.0;
        double maxDemandFactor = 2.0;
        return minDemandFactor + (maxDemandFactor - minDemandFactor) * random.nextDouble();
    }
    public void setIndex(int index) 
    {
        this.index = index;
    }
    
    public String toString() 
    {
        return "Block " + index + ":\n" +
                "Data: " + data + "\n" +
                "Timestamp: " + timeStamp + "\n" +
                "Nonce: " + nonce + "\n" +
                "Previous Hash: " + previousHash + "\n" +
                "Current Hash: " + hash + "\n" +
                "Transaction Fee: " + transactionFee + "\n" +
                "Gas Price: " + gasPrice;
    }
   
}

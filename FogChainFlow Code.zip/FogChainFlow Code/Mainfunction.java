package sample;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;


public class Mainfunction extends JFrame implements Serializable
{
	public static int numberOfSensor;
    public static int numberOfEdgeNode;
    public static int numberOfFogDevice;
    public static int numberOfFogNode;
    private static final long serialVersionUID = 1L;
    
    public Mainfunction() 
    {
        setTitle("Environment Creation");
        setSize(1200, 700);
        setLayout(new BorderLayout());
        JPanel inputPanel = new JPanel(new GridLayout(6, 2));
        
        JLabel sensorLabel = new JLabel("Number of sensors : ");
        sensorLabel.setBounds(500, 50, 150, 30);
        Font labelFont = new Font("Times New Roman", Font.BOLD, 16); 
        sensorLabel.setFont(labelFont);
        inputPanel.add(sensorLabel);

        JTextField sensorField = new JTextField();
        sensorField.setBounds(700, 50, 100, 30);
        inputPanel.add(sensorField);

        JLabel edgeNodeLabel = new JLabel("Number of EdgeNodes:");
        edgeNodeLabel.setBounds(500, 100, 200, 30);
        //Font labelFont1 = new Font("Times New Roman", Font.BOLD, 16); 
        edgeNodeLabel.setFont(labelFont);
        inputPanel.add(edgeNodeLabel);

        JTextField edgeNodeField = new JTextField();
        edgeNodeField.setBounds(700, 100, 100, 30);
        inputPanel.add(edgeNodeField);

        JLabel fogDeviceLabel = new JLabel("Number of FogDevices:");
        fogDeviceLabel.setBounds(500, 150, 200, 30);
        fogDeviceLabel.setFont(labelFont);
        inputPanel.add(fogDeviceLabel);

        JTextField fogDeviceField = new JTextField();
        fogDeviceField.setBounds(700, 150, 100, 30);
        inputPanel.add(fogDeviceField);

        JLabel fogNodeLabel = new JLabel("Number of FogNodes:");
        fogNodeLabel.setBounds(500, 200, 150, 30);
        fogNodeLabel.setFont(labelFont);
        inputPanel.add(fogNodeLabel);

        JTextField fogNodeField = new JTextField();
        fogNodeField.setBounds(700, 200, 100, 30);
        inputPanel.add(fogNodeField);

        JButton submitButton = new JButton("Submit");
        
        submitButton.addActionListener(e -> {
        	
            numberOfSensor = Integer.parseInt(sensorField.getText());
            numberOfEdgeNode = Integer.parseInt(edgeNodeField.getText());
            numberOfFogDevice = Integer.parseInt(fogDeviceField.getText());
            numberOfFogNode = Integer.parseInt(fogNodeField.getText());
            DrawingPanel drawingPanel = new DrawingPanel(numberOfSensor, numberOfEdgeNode, numberOfFogDevice, numberOfFogNode);
            add(drawingPanel, BorderLayout.CENTER);

          
            System.out.println("Number of sensors: " + numberOfSensor);
            System.out.println("Number of EdgeNodes: " + numberOfEdgeNode);
            System.out.println("Number of FogDevices: " + numberOfFogDevice);
            System.out.println("Number of FogNodes: " + numberOfFogNode);
            
            EdgeNode[] edgeNodes = new EdgeNode[numberOfEdgeNode];
            FogDevice[] fogDevice = new FogDevice[numberOfFogDevice];
            FogNode[] fogNode = new FogNode[numberOfFogNode];
            CloudNode cloudNode = new CloudNode(100);
            System.out.println("\n");
            List<FogNode> allFogNodes = new ArrayList<>();
                    
            for (int i = 0; i < numberOfEdgeNode; i++) 
            {
                //edgeNodes[i] = new EdgeNode("EdgeNode : " + (i + 1)+"\n");
            	edgeNodes[i] = new EdgeNode("EdgeNode : " + i +"\n");
            }
            
            for (int i = 0; i < numberOfFogDevice; i++) 
            {
                //fogDevice[i] = new FogDevice();
            	fogDevice[i] = new FogDevice(cloudNode,50);
            }
            
            for (int i = 0; i < numberOfFogNode; i++) 
            {
            	FogNode fogNode1 = new FogNode(allFogNodes,100); // Pass the list of all FogNodes
            	fogNode[i] = fogNode1;
            	allFogNodes.add(fogNode1);
            }
            
            for (EdgeNode edgeNode : edgeNodes) 
            {
                for (FogNode fogNode1 : fogNode) 
                {
                    edgeNode.addFogNode(fogNode1);
                }
                for (FogDevice fogDevice1 : fogDevice) 
                {
                    edgeNode.addFogDevice(fogDevice1);
                }
            }
            for (int i = 0; i < numberOfSensor; i++) 
            {
                //Sensor sensor = new Sensor("Sensor : " + i, edgeNodes[i % numberOfEdgeNode]);
            	
            	Sensor sensor = new Sensor("\n" + "Sensor : " + i, edgeNodes[i % numberOfEdgeNode]);
                int edgeNodeIndex = i % numberOfEdgeNode; // Assign sensors to edge nodes in a round-robin manner
                edgeNodes[edgeNodeIndex].addSensor(sensor);

                // Assuming a fixed number of readings to generate for each sensor
                int numberOfReadings = 5; // Change this value to generate a different number of readings per sensor
                sensor.generateData(numberOfReadings);
             // Loop through FogNodes to add received data for each generated reading
                for (FogNode fogNode2 : fogNode) 
                {
                    // Assuming bloodPressureData is a string array containing the generated data
                    String bloodPressureData = sensor.getBloodPressureData();
                    //for (String data : bloodPressureData) 
                    //{
                        fogNode2.receiveData("Received Blood Pressure Data: " + bloodPressureData);
                    //}
                }
            }
            
            //scanner.close();
            for (int i = 0; i < numberOfEdgeNode; i++) 
            {
                System.out.println("Data for " + edgeNodes[i].getNodeName());
                edgeNodes[i].printDataForEdgeNode(edgeNodes[i]);
                System.out.println(); // Add a line break for clarity
            }
            
         // Print updated data for each FogNode
            for (FogNode node : fogNode) 
            {
            	node.printDataForFogNode();
            	System.out.println("\n");
            }
            
            for (FogDevice device : fogDevice) 
            {
                device.printDataForFogDevice();
            }
            cloudNode.displayStoredData();
            
            revalidate();
            repaint();
            
        });
        inputPanel.add(submitButton);
        add(inputPanel, BorderLayout.WEST);

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        add(closeButton, BorderLayout.SOUTH);

        setVisible(true);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

	public static void main(String[] args) 
	{
		new Mainfunction();
	}
}
class DrawingPanel extends JPanel implements Serializable
{
    private final int numberOfSensor;
    private final int numberOfEdgeNode;
    private final int numberOfFogDevice;
    private final int numberOfFogNode;
    private static final long serialVersionUID = 1L;

    DrawingPanel(int numberOfSensor, int numberOfEdgeNode, int numberOfFogDevice, int numberOfFogNode) 
    {
        this.numberOfSensor = numberOfSensor;
        this.numberOfEdgeNode = numberOfEdgeNode;
        this.numberOfFogDevice = numberOfFogDevice;
        this.numberOfFogNode = numberOfFogNode;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int panelWidth = getWidth();
        int panelHeight = getHeight();

        int sensorRadius = 10;
        int edgeNodeRadius = 15;
        int fogDeviceRadius = 20;
        int fogNodeRadius = 25;
        int cloudNodeRadius = 30;

        int sensorSpacing = 50;
        int edgeNodeSpacing = 100;
        int fogDeviceSpacing = 150;
        int fogNodeSpacing = 200;
        int cloudNodeSpacing = 250;

        int centerX = panelWidth / 2;
        int centerY = panelHeight / 2;

        g.setColor(Color.BLUE);
        int sensorAngleStep = 360 / numberOfSensor;
        for (int i = 0; i < numberOfSensor; i++) {
            double angle = Math.toRadians(i * sensorAngleStep);
            int x = (int) (centerX + (sensorSpacing * Math.cos(angle))) - sensorRadius;
            int y = (int) (centerY + (sensorSpacing * Math.sin(angle))) - sensorRadius;
            g.fillOval(x, y, 2 * sensorRadius, 2 * sensorRadius);
        }

        /*g.setColor(Color.RED);
        int edgeNodeAngleStep = 360 / numberOfEdgeNode;
        for (int i = 0; i < numberOfEdgeNode; i++) {
            double angle = Math.toRadians(i * edgeNodeAngleStep);
            int x = (int) (centerX + (edgeNodeSpacing * Math.cos(angle))) - edgeNodeRadius;
            int y = (int) (centerY + (edgeNodeSpacing * Math.sin(angle))) - edgeNodeRadius;
            g.fillOval(x, y, 2 * edgeNodeRadius, 2 * edgeNodeRadius);
        }

        g.setColor(Color.GREEN);
        int fogDeviceAngleStep = 360 / numberOfFogDevice;
        for (int i = 0; i < numberOfFogDevice; i++) {
            double angle = Math.toRadians(i * fogDeviceAngleStep);
            int x = (int) (centerX + (fogDeviceSpacing * Math.cos(angle))) - fogDeviceRadius;
            int y = (int) (centerY + (fogDeviceSpacing * Math.sin(angle))) - fogDeviceRadius;
            g.fillOval(x, y, 2 * fogDeviceRadius, 2 * fogDeviceRadius);
        }

        g.setColor(Color.ORANGE);
        int fogNodeAngleStep = 360 / numberOfFogNode;
        for (int i = 0; i < numberOfFogNode; i++) {
            double angle = Math.toRadians(i * fogNodeAngleStep);
            int x = (int) (centerX + (fogNodeSpacing * Math.cos(angle))) - fogNodeRadius;
            int y = (int) (centerY + (fogNodeSpacing * Math.sin(angle))) - fogNodeRadius;
            g.fillOval(x, y, 2 * fogNodeRadius, 2 * fogNodeRadius);
        }

        g.setColor(Color.CYAN);
        //int cloudNodeAngleStep = 360;
        int x = (int) (centerX + (cloudNodeSpacing * Math.cos(0))) - cloudNodeRadius;
        int y = (int) (centerY + (cloudNodeSpacing * Math.sin(0))) - cloudNodeRadius;
        g.fillOval(x, y, 2 * cloudNodeRadius, 2 * cloudNodeRadius);

        g.setColor(Color.BLACK);
        for (int i = 0; i < numberOfSensor; i++) {
            double sensorAngle = Math.toRadians(i * sensorAngleStep);
            double edgeNodeAngle = Math.toRadians(i * edgeNodeAngleStep);
            double fogDeviceAngle = Math.toRadians(i * fogDeviceAngleStep);
            double fogNodeAngle = Math.toRadians(i * fogNodeAngleStep);

            int sensorX = (int) (centerX + (sensorSpacing * Math.cos(sensorAngle)));
            int sensorY = (int) (centerY + (sensorSpacing * Math.sin(sensorAngle)));

            int edgeNodeX = (int) (centerX + (edgeNodeSpacing * Math.cos(edgeNodeAngle)));
            int edgeNodeY = (int) (centerY + (edgeNodeSpacing * Math.sin(edgeNodeAngle)));

            int fogDeviceX = (int) (centerX + (fogDeviceSpacing * Math.cos(fogDeviceAngle)));
            int fogDeviceY = (int) (centerY + (fogDeviceSpacing * Math.sin(fogDeviceAngle)));

            int fogNodeX = (int) (centerX + (fogNodeSpacing * Math.cos(fogNodeAngle)));
            int fogNodeY = (int) (centerY + (fogNodeSpacing * Math.sin(fogNodeAngle)));

            int cloudNodeX = (int) (centerX + (cloudNodeSpacing * Math.cos(0)));
            int cloudNodeY = (int) (centerY + (cloudNodeSpacing * Math.sin(0)));

            g.drawLine(sensorX, sensorY, edgeNodeX, edgeNodeY);
            g.drawLine(edgeNodeX, edgeNodeY, fogDeviceX, fogDeviceY);
            g.drawLine(fogDeviceX, fogDeviceY, fogNodeX, fogNodeY);
            g.drawLine(fogNodeX, fogNodeY, cloudNodeX, cloudNodeY);
        }*/
        g.setColor(Color.RED); // Edge Nodes
        for (int i = 0; i < numberOfEdgeNode; i++) {
            int x = centerX - edgeNodeSpacing * i;
            int y = centerY;
            g.fillOval(x - edgeNodeRadius, y - edgeNodeRadius, 2 * edgeNodeRadius, 2 * edgeNodeRadius);
        }

        g.setColor(Color.GREEN); // Fog Devices
        for (int i = 0; i < numberOfFogDevice; i++) {
            int x = centerX - fogDeviceSpacing * i;
            int y = centerY - fogDeviceSpacing;
            g.fillOval(x - fogDeviceRadius, y - fogDeviceRadius, 2 * fogDeviceRadius, 2 * fogDeviceRadius);
        }

        g.setColor(Color.ORANGE); // Fog Nodes
        for (int i = 0; i < numberOfFogNode; i++) {
            int x = centerX - fogNodeSpacing * i;
            int y = centerY - fogNodeSpacing;
            g.fillOval(x - fogNodeRadius, y + fogNodeSpacing, 2 * fogNodeRadius, 2 * fogNodeRadius);
        }

        g.setColor(Color.CYAN); // Cloud Node
        int x = centerX;
        int y = centerY + cloudNodeSpacing;
        g.fillOval(x - cloudNodeRadius, y + cloudNodeRadius, 2 * cloudNodeRadius, 2 * cloudNodeRadius);

        g.setColor(Color.BLACK); // Draw connections
        for (int i = 0; i < numberOfEdgeNode; i++) {
            int edgeNodeX = centerX - edgeNodeSpacing * i;
            int edgeNodeY = centerY;
            g.drawLine(edgeNodeX, edgeNodeY, centerX - fogDeviceSpacing * i, centerY - fogDeviceSpacing);
        }

        for (int i = 0; i < numberOfFogDevice; i++) {
            int fogDeviceX = centerX - fogDeviceSpacing * i;
            int fogDeviceY = centerY - fogDeviceSpacing;
            g.drawLine(fogDeviceX, fogDeviceY, centerX - fogNodeSpacing * i, centerY - fogNodeSpacing + fogNodeSpacing);
        }

        for (int i = 0; i < numberOfFogNode; i++) {
            int fogNodeX = centerX - fogNodeSpacing * i;
            int fogNodeY = centerY - fogNodeSpacing + fogNodeSpacing;
            g.drawLine(fogNodeX, fogNodeY, centerX, centerY + cloudNodeSpacing);
        }
    }
}


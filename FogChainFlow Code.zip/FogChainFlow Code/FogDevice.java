package sample;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class FogDevice 
{
    private Map<String, ArrayList<String>> fogDeviceDataStorage;
	private int fogDeviceIndex1;
	private CloudNode cloudNode;
	private static final String secretKey = "SecretKeyaesi123";
    private static final String transformation = "AES";
    private int storageCapacity;
    private int usedStorage;
    public FogDevice(CloudNode cloudNode, int storageCapacity) 
    {
        fogDeviceDataStorage = new HashMap<>();
        this.cloudNode = cloudNode;
        this.storageCapacity = storageCapacity;
        this.usedStorage = 0;
    }
    
    public String getNodeName() 
	{
        return "FogDevice"; // Replace this with actual node name logic
    }
    
    public void receiveDataFromEdgeNode(int fogDeviceIndex, String edgeNodeName,int systolicPressure, int diastolicPressure, int heartRate, double bodyTemperature) 
    {
    	String data = "Received Blood Pressure Data and HeartRate Data from " + edgeNodeName + " is Systolic: " + systolicPressure + ", Diastolic: " + diastolicPressure + ", HeartRate: " + heartRate + ", BodyTemperature: " + bodyTemperature;
        System.out.println("\n" + data);
        long startTime = System.currentTimeMillis();
        String encryptedData = encryptData(data);
        long endTime = System.currentTimeMillis();
        long encryptionTime = endTime - startTime;
        storeData(data);
        fogDeviceIndex1 = fogDeviceIndex;
        cloudNode.receiveDataFromFogDevice(encryptedData, encryptionTime); // Send received data to CloudNode
        /*//Decryption the data
        String decryptedData = decryptData(encryptedData);
        if (decryptedData != null) {
            System.out.println("Decrypted Data: " + decryptedData);
            // Further processing with decrypted data...
        } else {
            System.out.println("Decryption failed.");
        }*/
    }
    
    
    public void receiveDataFromEdgeNode(int fogDeviceIndex, String edgeNodeName,int systolicPressure, int diastolicPressure) 
    {
    	String data = "Received Blood Pressure Data from " + edgeNodeName + "is Systolic: " + systolicPressure + ", Diastolic: " + diastolicPressure;
        System.out.println("\n" + data);
        long startTime = System.currentTimeMillis();
        String encryptedData = encryptData(data);
        long endTime = System.currentTimeMillis();
        long encryptionTime = endTime - startTime;
        storeData(data);
        fogDeviceIndex1 = fogDeviceIndex;
        cloudNode.receiveDataFromFogDevice(encryptedData, encryptionTime); // Send received data to CloudNode
        /*//Decryption the data
        String decryptedData = decryptData(encryptedData);
        if (decryptedData != null) {
            System.out.println("Decrypted Data: " + decryptedData);
            // Further processing with decrypted data...
        } else {
            System.out.println("Decryption failed.");
        }*/
    }
    public void receiveDataFromEdgeNode(int fogDeviceIndex, String edgeNodeName,int heartRate) 
    {
    	String data = "Received HeartRate Data from " + edgeNodeName + "HeartRate: " + heartRate;
        System.out.println("\n" + data);
        long startTime = System.currentTimeMillis();
        String encryptedData = encryptData(data);
        long endTime = System.currentTimeMillis();
        long encryptionTime = endTime - startTime;
        storeData(data);
        fogDeviceIndex1 = fogDeviceIndex;
        cloudNode.receiveDataFromFogDevice(encryptedData, encryptionTime); // Send received data to CloudNode
        /*//Decryption the data
        String decryptedData = decryptData(encryptedData);
        if (decryptedData != null) {
            System.out.println("Decrypted Data: " + decryptedData);
            // Further processing with decrypted data...
        } else {
            System.out.println("Decryption failed.");
        }*/
    }
    public void receiveDataFromEdgeNode(int fogDeviceIndex, String edgeNodeName,double bodyTemperature) 
    {
    	String data = "Received BodyTemperature Data from " + edgeNodeName + "BodyTemperature: " + bodyTemperature;
        System.out.println("\n" + data);
        long startTime = System.currentTimeMillis();
        String encryptedData = encryptData(data);
        long endTime = System.currentTimeMillis();
        long encryptionTime = endTime - startTime;
        storeData(data);
        fogDeviceIndex1 = fogDeviceIndex;
        cloudNode.receiveDataFromFogDevice(encryptedData, encryptionTime); // Send received data to CloudNode
        /*//Decryption the data
        String decryptedData = decryptData(encryptedData);
        if (decryptedData != null) {
            System.out.println("Decrypted Data: " + decryptedData);
            // Further processing with decrypted data...
        } else {
            System.out.println("Decryption failed.");
        }*/
    }
    private void storeData(String data) 
    {
    	if (usedStorage < storageCapacity) 
    	{
        // Store data received in Fog Device
    		if (!fogDeviceDataStorage.containsKey(data)) 
    		{
    			fogDeviceDataStorage.put(data, new ArrayList<>());
    		}
    		fogDeviceDataStorage.get(data).add(data);
    		usedStorage++; // Increment used storage
    		//System.out.println("Data stored in FogDevice. Remaining storage: " + (storageCapacity - usedStorage));
    	} 
    	else 
    	{
    		System.out.println("FogDevice storage is full.");
    	}
    }
 // Method to encrypt data using AES encryption
    private String encryptData(String data) {
        try {
            if (secretKey.length() != 16) {
                throw new IllegalArgumentException("AES key must be 16 characters");
            }

            Key key = new SecretKeySpec(secretKey.getBytes(), transformation);
            Cipher cipher = Cipher.getInstance(transformation);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encryptedBytes = cipher.doFinal(data.getBytes());
            return Base64.getEncoder().encodeToString(encryptedBytes);
        } catch (Exception e) {
            System.out.println("Encryption failed: " + e.getMessage());
            return null;
        }
    }
    /*private String decryptData(String data) {
        try {
            if (secretKey.length() != 16) {
                throw new IllegalArgumentException("AES key must be 16 characters");
            }

            Key key = new SecretKeySpec(secretKey.getBytes(), transformation);
            Cipher cipher = Cipher.getInstance(transformation);
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] decodedBytes = Base64.getDecoder().decode(data);
            byte[] decryptedBytes = cipher.doFinal(decodedBytes);
            return new String(decryptedBytes);
        } catch (Exception e) {
            System.out.println("Decryption failed: " + e.getMessage());
            return null;
        }
    }*/
    public void printDataForFogDevice() 
    {
        System.out.println("\n" + "Fog Device:" + fogDeviceIndex1 + "\n");
        for (String key : fogDeviceDataStorage.keySet()) 
        {
            System.out.println(key + "\n");
        }
        System.out.println("\n");
        System.out.println("Remaining storage capacity of FogDevice : " + fogDeviceIndex1 + " is " + (storageCapacity - usedStorage));
        
    }
 }
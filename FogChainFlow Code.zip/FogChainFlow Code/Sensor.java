package sample;
import java.util.Random;
public class Sensor 
{
	private String sensorId;
	private Random random;
    private EdgeNode edgeNode;
    int lastSystolicPressure, lastDiastolicPressure, lastHeartRate; 
    double lastBodyTemperature;
    public Sensor(String sensorId, EdgeNode edgeNode) 
    {
    	this.sensorId = sensorId;
    	this.random = new Random();
        this.edgeNode = edgeNode; // Assuming EdgeNode instance is created in the Sensor
    }
    
    public String getSensorId() 
    {
        return sensorId;
    }
    
    public void generateData(int numberofreadings) 
    {
    	int systolicPressure, diastolicPressure, heartRate;
    	double bodytemperature; 
    	long startTime, endTime;
        for(int i=0;i<numberofreadings;i++)
        {
        	systolicPressure = random.nextInt(80) + 90; // Generating systolic pressure between 90 and 170
        	diastolicPressure = random.nextInt(50) + 60; // Generating diastolic pressure between 60 and 110
        	heartRate = random.nextInt(60) + 50;
        	bodytemperature = random.nextDouble()*6 + 94;
        	System.out.println(sensorId + "\nGenerating Blood Pressure, HeartRate and BodyTemperature Data: Systolic: " + systolicPressure + ", Diastolic: " + diastolicPressure + ", HeartRate: " + heartRate + ", BodyTemperature: " + bodytemperature);
        	startTime = System.currentTimeMillis();
        	sendDataToEdgeNode(systolicPressure, diastolicPressure, heartRate, bodytemperature);
        	endTime = System.currentTimeMillis();
        	long elapsedTime = endTime - startTime;
        	double elapsedTimeInSeconds = elapsedTime / 1000.0; 
        	System.out.println("\n" + "Performance Evaluation of Sensor-to-Cloud Communication through Edge and Fog Computing Layers : " + elapsedTimeInSeconds + " Seconds" + "\n");
        	lastSystolicPressure = systolicPressure; // Store the last generated values
            lastDiastolicPressure = diastolicPressure;
            lastHeartRate = heartRate;
            lastBodyTemperature = bodytemperature;
        }
    }
    
    public int getLastSystolicPressure() 
    {
        return lastSystolicPressure;
    }

    public int getLastDiastolicPressure() 
    {
        return lastDiastolicPressure;
    }
    
    public int getLastHeartRate() 
    {
        return lastHeartRate;
    }
    
    public double getBodyTemperature() 
    {
        return lastBodyTemperature;
    }
    // Method to retrieve blood pressure data
    public String getBloodPressureData() 
    {
        return "Systolic: " + lastSystolicPressure + ", Diastolic: " + lastDiastolicPressure + ", Heart Rate: " + lastHeartRate + ", BodyTemperature: " + lastBodyTemperature;
    }
    
    public void sendDataToEdgeNode(int systolicPressure, int diastolicPressure, int heartRate, double bodytemperature) 
    {
    	edgeNode.receiveBloodPressureData(this, systolicPressure, diastolicPressure, heartRate, bodytemperature);
    }
}
